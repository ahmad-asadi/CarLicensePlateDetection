var InputName={
    "width":133,
    "height":25,
    "marginLeft":0,
    "marginRight":120,
    "marginTop":0,
    "marginBottom":0
}
var SpanLoginName={
    "marginTop":0
}
var SpanPassword={

}
var InputPassword={        
    "width":133,
    "height":25,
    "marginLeft":0,
    "marginRight":120,
    "marginTop":0,
    "marginBottom":0
}
var LoginButton={
    "width":88,
    "height":28,
    "marginLeft":0,
    "marginRight":0,
    "marginTop":0,
    "marginBottom":0
}
var LogoNumbers=1;
//var LoardAddress="http://xmsecu.com:8080/ocx/NewActive.exe";//if Null download cab else download exe 
var LoardAddress="";

var cabAddress="web.cab#version=1,0,0,84";
var DownLoadAddr="http://xmsecu.com:8080/ocx/NewActive.exe"
var logoString='NetSurveillance';
var copyright=2013
