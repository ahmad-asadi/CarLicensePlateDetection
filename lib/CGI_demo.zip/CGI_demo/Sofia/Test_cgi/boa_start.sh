#!/bin/sh
./boa -c ./
